# 1090 MHz ADS-B Ground Station — RF Receive-Chain Design & Characterization

A ground station that receives aircraft transponder signals at 1090 MHz — built as an exercise in **RF receive-chain engineering**, from antenna electromagnetics through low-noise amplification, signal capture, and a full data pipeline. End-to-end ownership of the design: antenna tuning and VNA characterization, a custom low-noise amplifier PCB, empirical RF diagnostics, embedded integration, and a web-based airspace replay tool.

This is not a flight-tracker built from a kit. The engineering content is the antenna and the amplifier — the things in front of the radio.

![KiCad](https://img.shields.io/badge/PCB-KiCad%209-blue)
![Python](https://img.shields.io/badge/Software-Python-3776AB)
![Raspberry Pi](https://img.shields.io/badge/Compute-Raspberry%20Pi%205-C51A4A)
![ESP32](https://img.shields.io/badge/Embedded-ESP32--C6-000000)
![RF](https://img.shields.io/badge/Domain-RF%20%2F%201090%20MHz-success)

---

## Selected results

| Metric | Result | How it was obtained |
|---|---|---|
| Demonstrated range | **127–140 nmi** | Live decode in dense PDX-area airspace; siting/horizon-limited |
| Antenna match | **S11 = −27.83 dB** (VSWR ≈ 1.08) | Measured on NanoVNA after active tuning |
| Feedpoint impedance | **Z ≈ 46.4 + j1.6 Ω** | NanoVNA, sanity-checks the EM model |
| Receive-chain gain | **46.4 dB** (optimized) | Backed off from 49.6 dB after diagnosing ADC overload |
| Custom LNA (in design) | **~0.6 dB NF / ~18 dB gain** (target) | PGA-103+ MMIC; simulation + datasheet, bench validation planned |

---

## What this project demonstrates

**1. Antenna design and measurement.** A quarter-wave ground-plane antenna designed, built, and tuned to a measured **S11 of −27.83 dB** on a NanoVNA — 66 mm radiator, four ~69 mm radials swept 45° downward to raise feedpoint impedance toward 50 Ω. The measured feedpoint impedance is used as a sanity check against a 4nec2 electromagnetic model. This is real impedance-matching work, not "screw on an antenna."

**2. A custom low-noise amplifier (in design).** Designing an LNA around the Mini-Circuits **PGA-103+** E-pHEMT MMIC, laid out in KiCad and simulated in QucsStudio. The interesting decisions are cascade-level: filter placement is set by Friis (LNA-before-SAW so the filter's insertion loss lands *after* the gain, not in front of it), and the part is self-biased — drain voltage through an RF choke sets operating current internally, which removes the external bias network and boost converter the earlier discrete design needed. See [`/lna`](./lna).

**3. Empirical RF diagnostics.** The headline failure mode in dense airspace isn't weak signal — it's **front-end overload**. Diagnosed ADC clipping from receiver telemetry (`peak_signal` near full-scale in `stats.json`), correlated it with mid-range track break-up, and corrected it by treating gain as a *dynamic-range positioning* control rather than a sensitivity knob. Range is bounded by siting and the horizon; the binding constraints are overload headroom and linearity, not noise figure.

**4. A full data pipeline.** A 1 Hz telemetry logger (Python + systemd) writes ~40-field rows per aircraft to disk with daily UTC rotation, feeding a self-built web replay tool that scrubs historical airspace on a Leaflet map. Migration to a columnar DuckDB/Parquet store is in progress. See [`/data`](./data).

**5. Embedded integration.** An ESP32-C6 polls the decoder's JSON feed and drives an OLED status display (aircraft count, max range, message rate, uptime). See [`/display`](./display).

---

## System architecture

```mermaid
flowchart LR
    A["Ground-plane antenna<br/>S11 = −27.83 dB"] -->|LMR240| B["LNA<br/>PGA-103+ (in design)<br/>or TQP3M9009 module"]
    B --> C["SAW filter<br/>TA1090EC"]
    C --> D["RTL-SDR V5<br/>gain 46.4 dB"]
    D --> E["Raspberry Pi 5<br/>dump1090-fa"]
    E --> F["tar1090<br/>web map"]
    E --> G["Telemetry logger<br/>1 Hz, ~40 fields"]
    G --> H["CSV → DuckDB/Parquet<br/>(migration in progress)"]
    H --> I["Airspace replay tool<br/>Leaflet"]
    E --> J["ESP32-C6<br/>OLED status display"]
```

The signal chain is ordered deliberately: amplify first (the LNA sets the system noise figure), then filter. Coax is **LMR240** (~0.13 dB/ft at 1090 MHz) for permanent runs — short RG316 pigtails only.

---

## Engineering decisions

A few decisions that each reduce to a one-line rationale — the full log is in [`docs/engineering-decisions.md`](./docs/engineering-decisions.md).

- **Gain is a dynamic-range control, not a sensitivity control** → backed off 49.6 → 46.4 dB to clear ADC clipping that was breaking mid-range tracks.
- **LNA before SAW (Friis)** → the SAW's insertion loss divided by the LNA gain is negligible; putting the filter first would cost noise figure directly.
- **PGA-103+ over a discrete BJT design** → self-biasing removes the external bias network and boost converter; ~0.6 dB NF and high OIP3 beat the abandoned BFR92P design on every axis that matters.
- **5 V rail over 3 V** → noise figure is identical on this part; 5 V buys linearity headroom, which is the binding constraint here.
- **Optimize the antenna and siting before the amplifier** → the performance hierarchy is antenna/siting → LNA and coax → gain → decoder. The big decibels are at the top.

---

## Skills & tools

| Domain | Tools / methods |
|---|---|
| **RF design** | Friis cascade analysis, S-parameters, Smith chart, LNA design, SAW filtering, stability (K-factor) |
| **Antenna** | Ground-plane design, impedance matching, NanoVNA characterization, 4nec2 EM modeling |
| **PCB** | KiCad 9, MMIC bring-up, RF-aware layout |
| **Simulation** | QucsStudio, uSimmics, LTSpice |
| **Embedded** | ESP32-C6, Arduino, I²C OLED, ArduinoJson |
| **Software / data** | Python, systemd, Leaflet.js, DuckDB/Parquet, Raspberry Pi / Linux |
| **RF test** | VNA, SMA attenuators, PLL synthesizer for compression testing |

---

## Repository map

| Path | Contents |
|---|---|
| [`antenna/`](./antenna) | Ground-plane antenna design, geometry, and NanoVNA characterization |
| [`lna/`](./lna) | Custom PGA-103+ LNA — schematic, simulation, layout (in design) |
| [`receiver/`](./receiver) | RTL-SDR + Raspberry Pi decode stack (dump1090-fa, tar1090) |
| [`data/`](./data) | Telemetry logger and web-based airspace replay tool |
| [`display/`](./display) | ESP32-C6 OLED status display |
| [`docs/`](./docs) | Architecture write-up and engineering decision log |

---

## Roadmap

- **DME/TACAN interference characterization** — `rtl_power` survey across 960–1215 MHz to decide whether a filter-first variant is warranted near PDX.
- **LNA fabrication & bench validation** — finish stability/NF simulation, fab the board, A/B against the current module.
- **Directional Yagi** — 5–6 element 1090 MHz Yagi modeled in 4nec2/MMANA-GAL, aimed at PDX.
- **Dual-receiver A/B** — second RTL-SDR on a Pi Zero W for per-aircraft RSSI deltas (joined on ICAO hex + timestamp).
- **Anomaly detection** — emergency squawks, implausible kinematics, GPS-spoofing indicators via classical methods.

---

## About

Built by a rising-junior Electrical Engineering student as RF portfolio work toward aerospace internships. The focus throughout is on defensible engineering reasoning — every design choice carries a one-line rationale, and performance figures are tied to measurements or labeled as design targets pending bench validation.
