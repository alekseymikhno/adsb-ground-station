# Antenna — quarter-wave ground plane

A vertically polarized quarter-wave ground-plane antenna for 1090 MHz, designed, built, and tuned by measurement.

## Design

| Parameter | Value |
|---|---|
| Radiator | 66 mm vertical element |
| Radials | 4 × ~69 mm, swept ~45° downward |
| Conductor | 18 AWG solid bare copper |
| Connector | Superbat SMA female 4-hole flange |
| Polarization | Vertical |

The radials are bent ~45° below horizontal to raise the feedpoint impedance from the ~36 Ω of a flat ground plane toward 50 Ω, improving the match without a separate matching network.

## Measured characterization (NanoVNA)

| Parameter | Value |
|---|---|
| S11 | **−27.83 dB** |
| VSWR | ≈ 1.08 |
| Feedpoint impedance | Z ≈ 46.4 + j1.6 Ω |

The measured impedance doubles as a sanity check for the 4nec2 electromagnetic model (geometry, ground parameters), so modeled gain can be trusted against a known-good data point.

## Files to add

- NanoVNA Touchstone (`.s1p`) sweeps
- 4nec2 model (`.nec`) and gain pattern exports
- Build photos / dimensioned sketch
