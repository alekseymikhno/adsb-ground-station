# Data — telemetry logger & airspace replay tool

## Telemetry logger

A Python service (systemd-managed) that polls the decoder's live `aircraft.json` at **1 Hz** and writes ~40-field rows per aircraft to disk, with daily UTC file rotation. This is the raw record the replay tool and future analysis layers run against.

## Airspace replay tool

A self-contained web app for scrubbing back through logged airspace:

- **Backend** — a small stdlib-only HTTP server exposing a few endpoints, caching processed days to disk.
- **Frontend** — a dark-themed Leaflet map with a date selector and a second-of-day time slider, rendering trailing aircraft history so any past window can be replayed.

## In progress

- **DuckDB / Parquet migration** — moving from flat CSV to a columnar store for fast historical queries. A `receiver_id` column is added to the schema *before* migration, so a second receiver can be joined in later without a retrofit.

## Files to add

- `logger.py` (+ systemd unit)
- `airspace_server.py`, `airspace_map.html`
- schema notes
