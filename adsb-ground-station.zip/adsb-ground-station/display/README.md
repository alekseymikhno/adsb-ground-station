# Display — ESP32-C6 OLED status panel

A standalone embedded status display for the station.

## Hardware

- **MCU:** Seeed XIAO ESP32-C6
- **Display:** 0.96" SSD1306 OLED over I²C (SDA D4 / SCL D5)

## Function

Polls the decoder's `aircraft.json` over WiFi every 5 seconds and shows live station stats:

- Aircraft count (gated on valid lat/lon)
- Max range (nmi)
- Average RSSI
- Messages/sec
- Uptime and WiFi IP

## Software

Arduino framework with ArduinoJson v7 (a memory-efficient parse filter pulls only the needed fields), Adafruit_SSD1306, and Adafruit_GFX.

## Next steps

- 3D-printed enclosure
- Battery indicator (divider into GPIO0 + `analogReadMilliVolts()`) — prototyped, currently stubbed out in code

## Files to add

- Arduino sketch (`.ino`)
- enclosure STLs
