# Architecture

## Signal chain

```mermaid
flowchart LR
    A["Ground-plane antenna<br/>S11 = −27.83 dB<br/>Z ≈ 46.4 + j1.6 Ω"] -->|LMR240| B["LNA<br/>PGA-103+ (in design)"]
    B --> C["SAW filter<br/>TA1090EC"]
    C --> D["RTL-SDR V5<br/>gain 46.4 dB"]
    D --> E["Raspberry Pi 5<br/>dump1090-fa"]
```

The receive chain is ordered to protect noise figure and dynamic range:

1. **Antenna** — vertically polarized quarter-wave ground plane, matched to ~50 Ω (measured S11 = −27.83 dB).
2. **Feedline** — LMR240 keeps pre-amplifier loss low, since any loss here adds to system NF.
3. **LNA** — sets the system noise figure with ~18 dB of low-noise gain. Placed before the filter so the filter's insertion loss is divided down by this gain (Friis).
4. **SAW filter** — rejects out-of-band energy after amplification.
5. **RTL-SDR V5** — software-defined radio digitizing the 1090 MHz signal; gain tuned to 46.4 dB to avoid ADC clipping.
6. **dump1090-fa** on a Raspberry Pi 5 — demodulates and decodes Mode S / ADS-B messages.

## Data flow

```mermaid
flowchart LR
    E["dump1090-fa<br/>aircraft.json"] --> F["tar1090 web map"]
    E --> G["Telemetry logger<br/>Python + systemd, 1 Hz"]
    G --> H["CSV (daily UTC rotation)"]
    H --> I["DuckDB / Parquet<br/>(migration in progress)"]
    H --> J["Airspace replay tool<br/>Leaflet + stdlib HTTP"]
    E --> K["ESP32-C6<br/>OLED status display"]
```

- **dump1090-fa** publishes a live `aircraft.json` snapshot, served visually through **tar1090**.
- A **systemd-managed Python logger** polls that snapshot at 1 Hz and writes ~40-field rows per aircraft, rotating files daily on UTC.
- The **airspace replay tool** reads the logged history and renders it on a dark-themed Leaflet map with a date selector and a time slider, so any past window of airspace can be scrubbed back through.
- An **ESP32-C6** independently polls the JSON feed and drives an OLED with live station stats.

## Notes on validation

Measured figures (antenna match, range, operating gain) come from the NanoVNA and live decode. The custom LNA's figures are design targets from simulation and the datasheet; the validation plan is a bench A/B against the existing TQP3M9009 module once the board is fabricated.
