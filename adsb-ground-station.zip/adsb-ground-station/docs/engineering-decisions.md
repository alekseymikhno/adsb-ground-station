# Engineering decisions

A running log of design decisions, each with the reasoning behind it. The point of this document is to show that the choices were deliberate and defensible — not defaults.

---

### Gain is a dynamic-range positioning control, not a sensitivity knob

**Context:** Mid-range aircraft tracks were breaking up intermittently.
**Diagnosis:** Receiver telemetry (`stats.json`) showed `peak_signal` sitting near full-scale — the ADC was clipping on strong nearby aircraft, and the resulting front-end overload was corrupting the weaker, more distant signals sharing the band.
**Decision:** Reduced gain from 49.6 dB to **46.4 dB**. Raising gain would have made the overload worse, not better. Gain sets *where* the signal population lands in the ADC's range; the job is to fit the strong and weak signals into the available bits without clipping.
**Result:** Mid-range break-up cleared. This reframed the whole station: it is siting- and horizon-limited, so **overload headroom and linearity** are the binding constraints — not noise figure.

---

### LNA before SAW filter (Friis cascade reasoning)

**Decision:** Place the low-noise amplifier *ahead* of the SAW band-pass filter.
**Reasoning:** In a Friis cascade, the noise contribution of a later stage is divided by the gain ahead of it. With ~18 dB of LNA gain first, the SAW's insertion loss contributes negligibly to system noise figure. Reverse the order and that same insertion loss adds almost directly to the NF.
**Open question:** Strong out-of-band emitters near PDX (DME/TACAN, 960–1215 MHz) could desensitize the front end. A filter-first variant is only justified if a spectrum survey confirms that desensitization — characterization is on the roadmap, not assumed.

---

### PGA-103+ MMIC over a discrete BJT design

**Context:** An earlier discrete BFR92P amplifier was abandoned — suspected DC bias error (emitter current past the fT peak), modest ~8.9 dB gain, and noise figure never properly simulated.
**Decision:** Redesign around the Mini-Circuits **PGA-103+** E-pHEMT MMIC.
**Why it wins:** ~0.6 dB NF, ~18 dB gain at 1 GHz, high P1dB and OIP3 for overload resilience — and it is **self-biased**. Drain voltage applied through an RF choke sets the operating current internally, which eliminates the external bias network *and* the boost converter the discrete design required. Fewer parts, fewer failure modes, better performance.
**Status:** In design — stability (K-factor) and NF simulation precede layout. All performance figures are datasheet/simulation targets until bench-validated against the existing module.

---

### 5 V rail over 3 V on the LNA

**Decision:** Operate the PGA-103+ from the higher supply rail.
**Reasoning:** Noise figure is effectively identical between the two rails on this part, so there is no NF penalty. The higher rail buys linearity (P1dB / OIP3) headroom — and linearity is the constraint that actually matters in this dense-airspace environment.

---

### Coax: LMR240 for runs, RG316 only for pigtails

**Decision:** LMR240 (~0.13 dB/ft at 1090 MHz) for any permanent feedline; RG316 (~1.0–1.2 dB/ft) restricted to short pigtails.
**Reasoning:** Loss ahead of the first amplifier adds directly to system noise figure. A few feet of the wrong cable can erase the advantage of a good LNA.

---

### Optimize antenna and siting before amplification

**Principle:** The performance hierarchy is **antenna/siting (tens of dB) → LNA and coax → gain setting → decoder**. Effort goes where the decibels are. A "better LNA" cannot rescue a station that is siting-limited, and the decoder choice has no bearing on RF performance at all.
