# LNA — custom PGA-103+ low-noise amplifier (in design)

A custom low-noise amplifier built around the Mini-Circuits **PGA-103+** E-pHEMT MMIC (SOT-89), laid out in KiCad 9 and simulated in QucsStudio.

## Target performance (datasheet / simulation)

| Parameter | Value |
|---|---|
| Noise figure | ~0.6 dB |
| Gain @ 1 GHz | ~18 dB |
| P1dB | +22.5 dBm |
| OIP3 | +41.9 dBm |

*These are design targets. Bench validation against the existing TQP3M9009 module is the acceptance test.*

## Why this design

- **Self-biased.** Drain voltage applied through an RF choke sets the operating current internally — no external bias resistor network, and no boost converter. This eliminated the entire bias subsystem the earlier discrete BFR92P design required.
- **Linearity headroom.** High P1dB/OIP3 matter more than a fraction of a dB of NF in this overload-limited environment. Operated from the 5 V rail for linearity, since NF is rail-independent on this part.
- **Cascade placement.** Sits ahead of the SAW filter (Friis): the filter's insertion loss is divided down by the LNA gain instead of adding to the front-end noise figure.

## Supply note

The receive path's bias tee supplies ~4.5 V; the datasheet 5 V curve is specified at 4.8 V minimum. This delta-from-spec operating point is characterized empirically rather than assumed — simulation uses the closest available S-parameter file (`PGA-103+_4.75V_Plus25DegC.s2p`).

## Status / next steps

- [ ] K-factor / stability analysis
- [ ] Noise-figure simulation
- [ ] KiCad layout finalization
- [ ] Fabrication
- [ ] Bench A/B vs. TQP3M9009 module

## Files to add

- KiCad project (schematic + PCB)
- QucsStudio simulation files
- S-parameter (`.s2p`) results, gerbers
