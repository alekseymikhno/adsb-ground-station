# Receiver — RTL-SDR + Raspberry Pi decode stack

The capture and decode back end.

## Hardware

- **SDR:** RTL-SDR V5 dongle, gain tuned to **46.4 dB**
- **Front end:** TA1090EC SAW + TQP3M9009 LNA module (the A/B baseline the custom LNA is measured against)
- **Compute:** Raspberry Pi 5

## Software

- **dump1090-fa** — Mode S / ADS-B demodulator and decoder (system package, gain set via `/etc/default/dump1090-fa`)
- **tar1090** — web map front end over the decoder's live aircraft feed

## Gain rationale

Gain was reduced from 49.6 dB to 46.4 dB after telemetry (`stats.json`) showed `peak_signal` near full-scale — ADC clipping on strong nearby aircraft was breaking up mid-range tracks. See [`../docs/engineering-decisions.md`](../docs/engineering-decisions.md).

## Files to add

- `dump1090-fa` config
- gain-sweep / stats notes
